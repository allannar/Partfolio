#Импорт
from flask import Flask, render_template, request, redirect, flash
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)

#Запуск страницы с контентом
@app.route('/')
def index():
    return render_template('index.html')


#Динамичные скиллы
@app.route('/', methods=['POST'])
def process_form():
    button_python = request.form.get('button_python')
    # 2. Секция добавить логику на остальные ссылки на проекты---
    button_discord = request.form.get('button_discord')

    # Логика формы обратной связи
    email = request.form.get('email')
    text = request.form.get('text')

    if email and text:
        with open("feedback.txt", "a", encoding="utf-8") as f:
            f.write(f"Email: {email}\nКомментарий: {text}\n{'-'*40}\n")

        return redirect('/')

    return render_template('index.html',
                           button_python=button_python,
                           button_discord=button_discord)


if __name__ == "__main__":
    app.run(debug=True)